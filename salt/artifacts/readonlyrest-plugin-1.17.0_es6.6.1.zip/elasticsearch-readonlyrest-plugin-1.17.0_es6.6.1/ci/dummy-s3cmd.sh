#!/usr/bin/env bash
echo $0 $@
